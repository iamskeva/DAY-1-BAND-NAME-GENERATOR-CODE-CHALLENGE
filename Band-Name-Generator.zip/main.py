#Welcome greeting for the program.
print ("Welcome to the Tech Hub Name Generator")

#Here I Ask the user for the city that they grew up in.

cityName = input("What's the name of your city? \n")

#Here I Ask the user for the name of a pet.
petName = input ("What is the name of your pet? \n")

#I Combine the name of their city and pet and show them their band name.

print ("Your name could be " + cityName + " " + petName)