#Your Life In Weeks Challenge
#The program tells user how many days, weeks, months they have left if they live until 90 years old.

# 🚨 Don't change the code below 👇
age = int(input("What is your current age?\n"))
# 🚨 Don't change the code above 👆

#Write your code below this line 👇

#Your Age Value
yourAgeInDays = age * 365
yourAgeInWeeks = age * 52
yourAgeInMonths = age * 12

#Value in Ninety Years

daysInNinetyYears = 90 * 365
weeksInNinetyYears = 90 * 52
monthsInNinetyYears = 90 * 12

#Your Remaining Days
daysRemaining = daysInNinetyYears - yourAgeInDays
weeksRemaining = weeksInNinetyYears - yourAgeInWeeks
monthsRemaining = monthsInNinetyYears - yourAgeInMonths

message = f"You Have {daysRemaining} days, {weeksRemaining} weeks, and {monthsRemaining} months left."

print(message)